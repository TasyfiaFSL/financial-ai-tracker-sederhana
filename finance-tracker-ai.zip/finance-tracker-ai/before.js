let saldo = 0;

function tambahPemasukan(jumlah) {
  saldo += jumlah;
}

function tambahPengeluaran(jumlah) {
  saldo -= jumlah;
}
